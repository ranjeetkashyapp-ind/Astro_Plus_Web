/* Public Google Identity Services Web Client ID. Replace before publishing. */
window.ASTROPLUS_AUTH_CONFIG = {
  googleClientId: 'REPLACE_WITH_GOOGLE_WEB_CLIENT_ID'
};
