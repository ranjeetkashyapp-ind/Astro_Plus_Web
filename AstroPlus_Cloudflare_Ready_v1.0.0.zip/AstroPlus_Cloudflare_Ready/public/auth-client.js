(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const state = { user: null, csrf: '', ready: false, busy: false };
  const cacheKey = 'astroPlusKundliProfiles';
  const message = (text, bad = false) => { const el = $('authMessage'); if (el) { el.textContent = text; el.style.color = bad ? '#b42318' : '#276749'; el.hidden = !text; } };
  const getCookie = (name) => document.cookie.split(';').map(x => x.trim()).find(x => x.startsWith(name + '='))?.slice(name.length + 1) || '';
  async function api(path, options = {}) {
    const method = options.method || 'GET';
    const headers = { ...(options.headers || {}) };
    if (options.body !== undefined) headers['Content-Type'] = 'application/json';
    if (!['GET', 'HEAD'].includes(method)) {
      if (!state.csrf && !getCookie('ap_csrf')) await initCsrf();
      headers['X-CSRF-Token'] = state.csrf || getCookie('ap_csrf');
    }
    const res = await fetch(path, { method, headers, body: options.body === undefined ? undefined : JSON.stringify(options.body), credentials: 'same-origin', cache: 'no-store' });
    let data = {}; try { data = await res.json(); } catch (_) {}
    if (!res.ok) throw new Error(data.message || data.error || `Request failed (${res.status})`);
    return data;
  }
  async function initCsrf() { const data = await api('/api/auth/csrf'); state.csrf = data.csrfToken || getCookie('ap_csrf'); }
  function localProfiles() { try { return JSON.parse(localStorage.getItem(cacheKey) || '[]'); } catch (_) { return []; } }
  function writeLocal(list) { try { localStorage.setItem(cacheKey, JSON.stringify(list)); } catch (_) {} }
  function mergeProfiles(remote, local) {
    const out = [...(remote || [])], keys = new Set(out.map(p => `${p.name}|${p.date}|${p.time}|${p.place}`));
    for (const p of (local || [])) { const k = `${p.name}|${p.date}|${p.time}|${p.place}`; if (!keys.has(k)) { out.push(p); keys.add(k); } }
    return out;
  }
  async function syncProfiles(list) {
    if (!state.user) return false;
    await api('/api/profiles', { method: 'PUT', body: { profiles: list } });
    return true;
  }
  async function hydrateProfiles() {
    if (!state.user) return;
    const local = localProfiles();
    const remote = await api('/api/profiles');
    const merged = mergeProfiles(remote.profiles || [], local);
    writeLocal(merged);
    if (merged.length !== (remote.profiles || []).length) await syncProfiles(merged);
    document.dispatchEvent(new CustomEvent('astroplus:profiles-updated'));
  }
  function updateAccountButton() {
    const btn = $('accountButton'); if (!btn) return;
    btn.textContent = state.user ? `मेरी प्रोफाइल · ${state.user.name || state.user.email}` : 'लॉगिन / साइन अप';
    btn.title = state.user ? `यूजर आईडी: ${state.user.id}` : 'Google या ईमेल से लॉगिन करें';
  }
  function setUser(user) {
    state.user = user || null; updateAccountButton();
    $('authSignedIn').hidden = !state.user;
    $('authSignedOut').hidden = !!state.user;
    $('authUserName').textContent = state.user ? (state.user.name || state.user.email) : '';
    $('authUserId').textContent = state.user ? state.user.id : '';
  }
  async function finishLogin(user) {
    setUser(user); await hydrateProfiles(); message('आपका Astro Plus अकाउंट सफलतापूर्वक लॉगिन हो गया है।');
    $('authEmailVerify').hidden = true; $('authModal').classList.add('open');
  }
  function openModal() { $('authModal').classList.add('open'); message(''); }
  function closeModal() { $('authModal').classList.remove('open'); }
  function setBusy(on) { state.busy = on; document.querySelectorAll('[data-auth-action]').forEach(b => { b.disabled = on; }); }
  async function withBusy(fn) { if (state.busy) return; setBusy(true); try { await fn(); } catch (e) { message(e.message || 'कुछ गलत हो गया।', true); } finally { setBusy(false); } }

  $('accountButton')?.addEventListener('click', openModal);
  $('authClose')?.addEventListener('click', closeModal);
  $('authModal')?.addEventListener('click', e => { if (e.target === $('authModal')) closeModal(); });
  $('authSignup')?.addEventListener('click', () => withBusy(async () => {
    const name = $('authName').value.trim(), email = $('authEmail').value.trim(), password = $('authPassword').value;
    const result = await api('/api/auth/email/signup', { method: 'POST', body: { name, email, password } });
    $('authVerifyEmail').value = email; $('authEmailVerify').hidden = false; message(result.message || 'ईमेल पर कोड भेज दिया गया है।');
  }));
  $('authVerify')?.addEventListener('click', () => withBusy(async () => {
    const result = await api('/api/auth/email/verify', { method: 'POST', body: { email: $('authVerifyEmail').value.trim(), code: $('authCode').value.trim() } });
    await finishLogin(result.user);
  }));
  $('authLogin')?.addEventListener('click', () => withBusy(async () => {
    const result = await api('/api/auth/email/login', { method: 'POST', body: { email: $('authEmail').value.trim(), password: $('authPassword').value } });
    await finishLogin(result.user);
  }));
  $('authLogout')?.addEventListener('click', () => withBusy(async () => {
    await api('/api/auth/logout', { method: 'POST', body: {} }); setUser(null); writeLocal([]); closeModal(); message('आप लॉगआउट हो गए हैं।');
  }));
  window.handleAstroPlusGoogleCredential = (response) => withBusy(async () => {
    const result = await api('/api/auth/google', { method: 'POST', body: { credential: response.credential } });
    await finishLogin(result.user);
  });
  async function startGoogle() {
    const clientId = window.ASTROPLUS_AUTH_CONFIG?.googleClientId;
    if (!clientId || clientId.includes('REPLACE_WITH')) { message('Google Client ID अभी सेट नहीं है। PUBLISHING_GUIDE_HI.txt में दिए निर्देश पूरे करें।', true); return; }
    if (!window.google?.accounts?.id) { message('Google Login लोड नहीं हुआ। इंटरनेट कनेक्शन जाँचें।', true); return; }
    window.google.accounts.id.initialize({ client_id: clientId, callback: window.handleAstroPlusGoogleCredential, auto_select: false, cancel_on_tap_outside: true });
    const host = $('googleButtonHost');
    if (!host) return;
    host.innerHTML = '';
    window.google.accounts.id.renderButton(host, { theme: 'outline', size: 'large', text: 'continue_with', shape: 'rectangular', width: Math.min(340, Math.max(240, host.clientWidth || 300)) });
    $('authGoogle').hidden = true;
  }
  $('authGoogle')?.addEventListener('click', startGoogle);
  window.AstroPlusAuth = {
    get user() { return state.user; },
    syncProfiles,
    requireLogin() { if (state.user) return true; openModal(); message('प्रोफाइल को आपके अकाउंट में सेव करने के लिए पहले लॉगिन करें।', true); return false; },
    async refreshProfiles() { await hydrateProfiles(); }
  };
  (async () => {
    try {
      await initCsrf();
      try { const data = await api('/api/auth/me'); setUser(data.user); await hydrateProfiles(); }
      catch (e) { setUser(null); }
    } catch (e) { setUser(null); console.warn('AstroPlus auth service is not configured yet:', e); }
    state.ready = true;
  })();
})();
