/* AstroPlus Faladesh Data Bridge v1.0.0
 * Independent adapter: Kundli iframe -> Faladesh engine iframe. No astrology calculations here.
 */
(function(){'use strict';
 const BRIDGE_VERSION='1.8.23';
 const ENGINE_FILE='AstroPlus_Faladesh_Integrated_Calculation_Engine_v2.8.80.html';
 // Resolve the engine beside this bridge script, not relative to the host page/archiveviewer URL.
 const BRIDGE_SCRIPT_URL=(document.currentScript&&document.currentScript.src)||location.href;
 let ENGINE_URL=ENGINE_FILE;try{const u=new URL(ENGINE_FILE,BRIDGE_SCRIPT_URL);u.searchParams.set('v','2.8.261');ENGINE_URL=u.href;}catch(e){}
 let engineFrame=null, engineApi=null, lastReport=null, ready=false, lastChartSignature=null;
 const status={bridge:'initializing',engine:'loading',lastTransfer:null,lastError:null};
 function emit(){try{window.dispatchEvent(new CustomEvent('astroplus:faladesh-status',{detail:{...status}}));}catch(e){}}
 function ensureEngine(){
   if(engineApi)return Promise.resolve(engineApi);
   if(engineFrame)return new Promise((resolve,reject)=>{
     let n=0;const t=setInterval(()=>{n++;try{engineApi=engineFrame.contentWindow.AstroPlusFaladeshEngine;}catch(e){status.lastError='Faladesh engine access error: '+e.message;}
       if(engineApi){clearInterval(t);status.engine='ready';status.lastError=null;emit();resolve(engineApi);}
       else if(n>300){clearInterval(t);status.engine='error';status.lastError='Faladesh engine load timeout: '+ENGINE_URL;emit();reject(new Error(status.lastError));}
     },100);
   });
   engineFrame=document.createElement('iframe');engineFrame.title='AstroPlus Faladesh Engine';engineFrame.setAttribute('aria-hidden','true');
   Object.assign(engineFrame.style,{position:'fixed',width:'1px',height:'1px',left:'-10px',bottom:'-10px',opacity:'0',pointerEvents:'none',border:'0'});
   return new Promise((resolve,reject)=>{
     let settled=false;const poll=setInterval(()=>{try{engineApi=engineFrame.contentWindow.AstroPlusFaladeshEngine;}catch(e){status.lastError='Faladesh engine access error: '+e.message;}
       if(engineApi&&!settled){settled=true;clearInterval(poll);status.engine='ready';status.lastError=null;emit();resolve(engineApi);}
     },100);
     engineFrame.addEventListener('error',()=>{if(!settled){settled=true;clearInterval(poll);status.engine='error';status.lastError='Faladesh engine file load failed: '+ENGINE_URL;emit();reject(new Error(status.lastError));}},{once:true});
     setTimeout(()=>{if(!settled){settled=true;clearInterval(poll);status.engine='error';status.lastError='Faladesh engine load timeout: '+ENGINE_URL;emit();reject(new Error(status.lastError));}},30000);
     engineFrame.src=ENGINE_URL;
     document.body.appendChild(engineFrame);
   });
 }
 function installIntoKundliDocument(html){
   const marker='const lagnaDegree=lagnaLon%30;';
   if(!html.includes(marker))throw new Error('Kundli calculation export point not found; source version mismatch.');
   if(html.includes('ASTROPLUS_FALADESH_BRIDGE_EXPORT'))return html;
   const hook=`${marker}
/* ASTROPLUS_FALADESH_BRIDGE_EXPORT: publish raw Kundli calculation results only */
try{
 const __apNow=now;
 const __apSpeed=(body)=>{try{const __a=siderealLongitude(Astronomy.Body[body],new Date(__apNow.getTime()-43200000));const __b=siderealLongitude(Astronomy.Body[body],new Date(__apNow.getTime()+43200000));return ((__b-__a+540)%360-180);}catch(e){return null;}};
 const __apBodyByName={'सूर्य':'Sun','चंद्र':'Moon','मंगल':'Mars','बुध':'Mercury','गुरु':'Jupiter','शुक्र':'Venus','शनि':'Saturn'};
 const __apProfile=(window.parent&&window.parent.__astroPlusSelectedProfile)||null;
 const __apBirth=selectedDateTime?selectedDateTime.toISOString():null;
 const __apMode=selectedDateTime===null?'live':'selected-time';
 // पंचांग तिथि/पक्ष उसी Kundli समय के सूर्य-चंद्र देशांतर से स्पष्ट रूप से भेजें।
 const __apMoon=data.find(p=>['चंद्र','चंद्रमा','चन्द्र'].includes(p.name)), __apSun=data.find(p=>p.name==='सूर्य');
 let __apPanchang=null;
 if(__apMoon&&__apSun&&Number.isFinite(Number(__apMoon.lon))&&Number.isFinite(Number(__apSun.lon))){
  const __apAngle=((Number(__apMoon.lon)-Number(__apSun.lon))%360+360)%360, __apWaxing=__apAngle>0&&__apAngle<=180;
  const __apNewMoon=__apAngle<0.000001||__apAngle>359.999999; const __apTithiNo=__apNewMoon?15:Math.max(1,Math.min(15,Math.floor((__apAngle<=180?__apAngle:__apAngle-180)/12)+1));
  const __apNames=['प्रतिपदा','द्वितीया','तृतीया','चतुर्थी','पंचमी','षष्ठी','सप्तमी','अष्टमी','नवमी','दशमी','एकादशी','द्वादशी','त्रयोदशी','चतुर्दशी','पूर्णिमा/अमावस्या'];
  __apPanchang={paksha:__apWaxing?'शुक्ल पक्ष':'कृष्ण पक्ष',tithi_number:__apTithiNo,tithi_name:__apAngle<0.000001||__apAngle>359.999999?'अमावस्या':__apTithiNo===15?(__apWaxing?'पूर्णिमा':'अमावस्या'):__apNames[__apTithiNo-1],source:'kundli_sun_moon_longitude',calculatedAt:__apNow.toISOString()};
 }
 const __apPayload={source:'AstroPlus Kundli',sourceVersion:'uploaded-kundli-file',calculationMode:__apMode,calculatedAt:__apNow.toISOString(),birthDateTime:__apBirth,panchang:__apPanchang,ayanamsha:ayanamsha(__apNow),houseSystem:'whole-sign',lagnaSign:lagnaSign,lagnaLongitude:lagnaLon,lagna:{signIndex:lagnaSign,siderealLongitude:lagnaLon},planets:data.map(p=>{
   const speed=p.name==='राहु'||p.name==='राहू'||p.name==='केतु'?-0.05295:__apSpeed(__apBodyByName[p.name]);
   const fixedDirect=p.name==='सूर्य'||p.name==='चंद्र'||p.name==='चंद्रमा';
   const fixedRetro=p.name==='राहु'||p.name==='राहू'||p.name==='केतु';
   const retrograde=fixedDirect?false:fixedRetro?true:(speed==null?null:speed<0);
   return {name:p.name,signIndex:p.sign,siderealLongitude:p.lon,dailyMotion:speed,retrograde,motionStatus:retrograde==null?'अज्ञात':retrograde?'वक्री':'मार्गी',house:((p.sign-lagnaSign+12)%12)+1};
  }),profileName:profileDisplayName||(__apProfile&&__apProfile.name)||''};
 window.parent.postMessage({type:'ASTROPLUS_FALADESH_KUNDLI_DATA',bridgeVersion:'${BRIDGE_VERSION}',payload:__apPayload},'*');
}catch(__apBridgeError){try{window.parent.postMessage({type:'ASTROPLUS_FALADESH_BRIDGE_ERROR',message:String(__apBridgeError&&__apBridgeError.message||__apBridgeError)},'*');}catch(e){}}
`;
   return html.replace(marker,hook);
 }
 function chartStateSignature(payload){
   const arcMinute=value=>{
     const n=Number(value);
     return Number.isFinite(n)?Math.round((((n%360)+360)%360)*60):null;
   };
   return JSON.stringify({
     source:payload.source||'',
     birthDateTime:payload.birthDateTime||null,
     profileName:payload.profileName||'',
     lagna:arcMinute(payload.lagnaLongitude ?? payload.lagna?.siderealLongitude),
     lagnaSign:payload.lagnaSign ?? payload.lagna?.signIndex ?? null,
     panchang:payload.panchang||payload.panchangData||payload.panchang_data||null,
     planets:payload.planets.map(p=>[
       p.name||'',
       p.signIndex??null,
       arcMinute(p.siderealLongitude),
       p.dailyMotion==null?null:Number(p.dailyMotion),p.retrograde??null,
       p.house??null
     ])
   });
 }
 async function processPayload(payload){
   if(!payload||!Array.isArray(payload.planets)||payload.planets.length!==9)throw new Error('कुंडली से सभी 9 ग्रहों का डेटा नहीं मिला।');
   const signature=chartStateSignature(payload);
   if(signature===lastChartSignature){
     status.bridge='connected';
     status.lastError=null;
     return lastReport;
   }
   const api=await ensureEngine();
   const input={...payload,calculationMode:payload.calculationMode||((payload.birthDateTime)?'selected-time':'live'),asOfDateTime:payload.birthDateTime||payload.calculatedAt||new Date().toISOString(),calculationSettings:{ayanamsha:'kundli-source',houseSystem:'whole-sign'}};
   const normalized=api.normalizeKundliInput(input);
   const report=api.buildCompleteCustomerReport(normalized);
   lastChartSignature=signature;
   lastReport=report;status.bridge='connected';status.lastTransfer=payload.calculatedAt||new Date().toISOString();status.lastError=null;
   window.AstroPlusFaladeshBridge.lastReport=report;
   window.dispatchEvent(new CustomEvent('astroplus:faladesh-report',{detail:report}));emit();
   return report;
 }
 function onMessage(event){
   if(event.source!==document.getElementById('kundliFrame')?.contentWindow)return;
   if(event.data?.type==='ASTROPLUS_FALADESH_KUNDLI_DATA')processPayload(event.data.payload).catch(e=>{status.bridge='error';status.lastError=e.message;emit();});
   if(event.data?.type==='ASTROPLUS_FALADESH_BRIDGE_ERROR'){status.bridge='error';status.lastError=event.data.message;emit();}
 }
 window.addEventListener('message',onMessage);
 window.AstroPlusFaladeshBridge={version:BRIDGE_VERSION,ensureEngine,installIntoKundliDocument,processPayload,getLastReport:()=>lastReport,getStatus:()=>({...status}),recalculate:()=>{const f=document.getElementById('kundliFrame');try{f?.contentWindow?.calc?.();}catch(e){}return lastReport;}};
 status.bridge='ready';emit();
})();
