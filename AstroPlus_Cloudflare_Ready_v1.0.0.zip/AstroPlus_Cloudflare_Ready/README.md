# Astro Plus — Cloudflare Pages + GitHub Ready

This folder is prepared for GitHub source control and Cloudflare Pages publishing. It includes the existing Astro Plus Kundli/Faladesh website, its independent Faladesh engine files, a Cloudflare Pages Functions authentication backend, and a D1 database migration for shared user accounts and saved Kundli profiles.

## Included

- `public/` — website files deployed by Cloudflare Pages.
- `functions/api/[[path]].js` — same-origin account/profile API (Cloudflare Pages Function).
- `migrations/0001_auth_profiles.sql` — D1 schema for users, sessions, verification, profiles and rate limits.
- `source/` — original editable Astro Plus HTML/JS/JSON sources and backup engine. `public/index.html` is the deployable host page with the account interface attached.
- `docs/PUBLISHING_GUIDE_HI.md` — complete Hindi setup and publishing instructions.
- `wrangler.toml` — Pages output directory and D1 binding placeholder.

## Important before going live

1. Create the Cloudflare D1 database and replace `REPLACE_WITH_YOUR_D1_DATABASE_ID` in `wrangler.toml`.
2. Set the same Google Web Client ID in `wrangler.toml` (`GOOGLE_CLIENT_ID`) and `public/auth-config.js` (`googleClientId`).
3. Add Cloudflare secrets `SESSION_SECRET`, `RESEND_API_KEY`, and `EMAIL_FROM` for production and preview as needed.
4. Apply the D1 migration before testing account registration.
5. Set `APP_ORIGIN` to the exact production origin (for example `https://astroplus.in`).

Do not commit real secrets, passwords, API keys, or `.dev.vars` files to GitHub.

## Account behavior

- Google sign-in/sign-up uses a verified Google ID token; the backend verifies its signature, issuer, audience and expiry before creating a session.
- Email sign-up uses a password and a one-time email verification code. Email login uses the verified email and password.
- Every account receives a stable unique Astro Plus user ID (`usr_...`).
- Saved Kundli profiles are stored under that user ID in D1 and are available to other Astro Plus pages on the same site origin through `/api/auth/me` and `/api/profiles`.
- Existing browser-local saved Kundli profiles are merged into the signed-in account at first login on that browser.
- Astrology calculation APIs, matchmaking, horoscope, daily horoscope and Panchang APIs are intentionally not built in this stage; those can be added later using the same account/session.

## Local development

1. Copy `.env.example` to `.dev.vars` and fill local test values. Never commit `.dev.vars`.
2. Run `npx wrangler@latest d1 create astroplus-accounts` once and copy its database ID into `wrangler.toml`.
3. Run `npx wrangler@latest d1 migrations apply astroplus-accounts --local`.
4. Run `npx wrangler@latest pages dev public` from this folder.

For production setup, follow `docs/PUBLISHING_GUIDE_HI.md`.
