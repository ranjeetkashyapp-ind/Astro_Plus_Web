# Astro Plus को GitHub और Cloudflare Pages पर पब्लिश करने की पूरी प्रक्रिया

यह फोल्डर Cloudflare Pages के लिए तैयार किया गया है। वेबसाइट `public/` से पब्लिश होगी। लॉगिन, साइन अप और प्रोफाइल सेव करने के लिए Cloudflare Pages Functions तथा D1 डेटाबेस का उपयोग होगा। कुंडली/फलादेश की बाकी गणना पहले की तरह वेबसाइट की मौजूदा फाइलों में ही रहेगी।

## 1. GitHub पर पूरा सोर्स कोड रखें
1. GitHub में नया private repository बनाएँ, उदाहरण `astroplus-cloudflare`।
2. इस पूरे `AstroPlus_Cloudflare_Ready` फोल्डर के अंदर की सभी फाइलें repository के root में अपलोड करें। केवल `public` नहीं; `functions`, `migrations`, `wrangler.toml`, `source` और `docs` भी जरूरी हैं।
3. `.gitignore` मौजूद है। `.dev.vars`, `.env` और असली API keys GitHub पर अपलोड न करें।

## 2. Cloudflare D1 डेटाबेस बनाएँ
1. Cloudflare Dashboard → Workers & Pages → D1 SQL Database → Create database चुनें। नाम `astroplus-accounts` रखें।
2. Database ID कॉपी करें और `wrangler.toml` में `REPLACE_WITH_YOUR_D1_DATABASE_ID` की जगह डालें।
3. D1 binding का नाम `DB` ही रखें।
4. Node.js LTS और Git वाले कंप्यूटर पर repository clone करके project folder में चलाएँ:

```bash
npx wrangler@latest login
npx wrangler@latest d1 migrations apply astroplus-accounts --remote
```

इससे users, sessions, pending email verification, Kundli profiles और rate-limit tables बनेंगी।

## 3. Google Login / Google Sign Up सेट करें
1. https://console.cloud.google.com/ खोलें और Astro Plus project चुनें/बनाएँ।
2. Google Auth Platform में Branding/Audience की आवश्यक जानकारी पूरी करें।
3. Clients में OAuth Client बनाएँ: Web application।
4. Authorized JavaScript origins में `https://astroplus.in` और testing के लिए `https://YOUR-PROJECT.pages.dev` जोड़ें।
5. Client ID कॉपी करें। इस Google Identity Services flow में Client Secret frontend में नहीं डालना है।
6. `public/auth-config.js` में `REPLACE_WITH_GOOGLE_WEB_CLIENT_ID` बदलें।
7. `wrangler.toml` के `GOOGLE_CLIENT_ID` में भी वही Client ID डालें। दोनों समान होने चाहिए।

Backend Google ID token की signature, issuer, audience, expiry और verified email जाँचता है।

## 4. ईमेल Sign Up / Email Login सेट करें
ईमेल साइन अप के 6 अंकों के verification code के लिए Resend जोड़ा गया है।
1. https://resend.com/ पर account बनाएँ, अपना domain verify करें और API key बनाएँ।
2. Verified sender address रखें, उदाहरण `Astro Plus <no-reply@astroplus.in>`।
3. Cloudflare Dashboard → Workers & Pages → Pages project → Settings → Variables and Secrets में ये तीनों **Secret** जोड़ें:
   - `SESSION_SECRET` — कम-से-कम 32 अक्षरों का random secret
   - `RESEND_API_KEY` — Resend API key
   - `EMAIL_FROM` — verified sender address
4. Secret बनाने के लिए local terminal में चलाएँ:

```bash
openssl rand -base64 48
```

वास्तविक secret को GitHub, HTML, JS या `wrangler.toml` में न रखें।

## 5. Cloudflare Pages को GitHub से जोड़ें
1. Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git चुनें।
2. GitHub repository `astroplus-cloudflare` चुनें।
3. Build settings:
   - Framework preset: `None`
   - Build command: खाली
   - Build output directory: `public`
   - Root directory: repository root
4. Deploy करें। Cloudflare `public/` से static website और root के `functions/` folder से API Functions deploy करेगा।
5. Pages Settings → Functions / Bindings में D1 binding जाँचें: variable `DB`, database `astroplus-accounts`।
6. Production Variables में `APP_ORIGIN` को exact origin दें, उदाहरण `https://astroplus.in`; `GOOGLE_CLIENT_ID` भी वही रखें।
7. `SESSION_SECRET`, `RESEND_API_KEY`, `EMAIL_FROM` Production Secrets में मौजूद हों। फिर redeploy करें।

## 6. अपना domain जोड़ें
Pages project → Custom domains में `astroplus.in` जोड़ें और Cloudflare के DNS निर्देश पूरे करें। SSL/TLS सक्रिय होने दें। Google OAuth में exact HTTPS origin दर्ज होना चाहिए। Domain बदलने पर `APP_ORIGIN` और Google origin भी बदलें।

## 7. पब्लिश होने के बाद जाँचें
- [ ] मुख्य वेबसाइट खुलती है और Kundli/Faladesh engine load होता है।
- [ ] Google Login से account बनता/लॉगिन होता है।
- [ ] Email signup पर verification code आता है और verify होता है।
- [ ] Email + password login चलता है।
- [ ] Account panel में unique Astro Plus User ID दिखती है।
- [ ] `प्रोफाइल जोड़ें` से saved Kundli profile D1 में सेव होती है।
- [ ] उसी account से दूसरे browser/device पर login करने पर profiles दिखती हैं।
- [ ] Logout के बाद profile API access बंद होता है।

## 8. भविष्य के सभी पेज एक ही अकाउंट से
Kundli Milan, Horoscope, Daily Horoscope, Panchang आदि को इसी domain/origin पर रखें। वे ये endpoints इस्तेमाल करेंगे:
- `GET /api/auth/me` — वर्तमान यूजर और unique ID
- `GET /api/profiles` — यूजर की saved Kundli profiles
- `PUT /api/profiles` — प्रोफाइल सूची अपडेट

हर नए feature का data अपने table में रखा जा सकता है, लेकिन सभी records इसी `user_id` से जुड़ेंगे।

## 9. अभी और बाद के काम
**अभी शामिल:** Cloudflare Pages structure, Google sign-in/sign-up, email/password sign-up/login, email verification, unique user ID, secure session cookie, D1 accounts और shared Kundli profiles।

**बाद में:** Kundli calculation API, Kundli Milan, Horoscope/Daily Horoscope, Panchang APIs, payment/wallet, consultation, Android app और admin/astrologer systems। इस चरण में astrology APIs नहीं बनाई गई हैं।

## सुरक्षा
Google ID token backend पर verify होता है। Password PBKDF2-SHA256 hash और unique salt के रूप में रखा जाता है। Session token HttpOnly cookie में और उसका hash D1 में रहता है। Mutating requests पर same-origin और CSRF checks तथा auth endpoints पर basic IP rate limiting है। Production में Cloudflare WAF/rate-limit rules और नियमित database backup भी चालू रखें। Secrets कभी GitHub पर commit न करें।
