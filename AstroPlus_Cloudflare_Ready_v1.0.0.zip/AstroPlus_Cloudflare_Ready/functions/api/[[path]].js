const SESSION_DAYS = 30;
const PBKDF2_ITERATIONS = 310000;
const encoder = new TextEncoder();
let googleKeysCache = null;
let googleKeysExpiry = 0;

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers } });
}
function b64url(bytes) {
  let s = ''; for (const b of new Uint8Array(bytes)) s += String.fromCharCode(b);
  return btoa(s).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}
function fromB64url(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '=';
  const raw = atob(s); return Uint8Array.from(raw, c => c.charCodeAt(0));
}
function randomToken(n = 32) { const a = new Uint8Array(n); crypto.getRandomValues(a); return b64url(a); }
async function sha256(s) { return b64url(await crypto.subtle.digest('SHA-256', encoder.encode(s))); }
async function hmac(s, secret) {
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return b64url(await crypto.subtle.sign('HMAC', key, encoder.encode(s)));
}
async function passwordHash(password, saltB64) {
  const salt = saltB64 ? fromB64url(saltB64) : crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' }, key, 256);
  return { salt: b64url(salt), hash: b64url(bits) };
}
function cookies(request) {
  const out = {}; for (const part of (request.headers.get('Cookie') || '').split(';')) {
    const i = part.indexOf('='); if (i > 0) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  } return out;
}
function cookie(name, value, request, options = {}) {
  const secure = new URL(request.url).protocol === 'https:' ? '; Secure' : '';
  const maxAge = options.maxAge ?? 60 * 60 * 24 * SESSION_DAYS;
  return `${name}=${value}; Path=/; Max-Age=${maxAge}; SameSite=Lax${options.httpOnly ? '; HttpOnly' : ''}${secure}`;
}
function checkOrigin(request, env) {
  const origin = request.headers.get('Origin');
  if (!origin) return true;
  try { return new URL(origin).origin === new URL(env.APP_ORIGIN || request.url).origin; } catch { return false; }
}
function checkCsrf(request) {
  const c = cookies(request), h = request.headers.get('X-CSRF-Token');
  return !!c.ap_csrf && !!h && c.ap_csrf === h;
}
async function body(request) { try { return await request.json(); } catch { return null; } }
function cleanEmail(v) { return String(v || '').trim().toLowerCase(); }
function validEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) && v.length <= 254; }
function safeUser(row) { return { id: row.id, email: row.email, name: row.name || '', emailVerified: !!row.email_verified, createdAt: row.created_at, providers: row.google_sub ? ['google', 'email'].filter((_, i) => i === 0 || !!row.password_hash) : (row.password_hash ? ['email'] : ['google']) }; }
async function issueSession(db, userId, request) {
  const token = randomToken(32), tokenHash = await sha256(token), now = Math.floor(Date.now() / 1000), expires = now + SESSION_DAYS * 86400;
  await db.prepare('DELETE FROM sessions WHERE expires_at<=?').bind(now).run();
  await db.prepare('INSERT INTO sessions (token_hash,user_id,created_at,expires_at) VALUES (?,?,?,?)').bind(tokenHash, userId, now, expires).run();
  return cookie('ap_session', token, request, { httpOnly: true, maxAge: SESSION_DAYS * 86400 });
}
async function currentUser(request, env) {
  const token = cookies(request).ap_session; if (!token) return null;
  const hash = await sha256(token), now = Math.floor(Date.now() / 1000);
  const row = await env.DB.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?').bind(hash, now).first();
  return row || null;
}

async function rateLimit(env, request, scope, limit, windowSeconds) {
  const now = Math.floor(Date.now() / 1000);
  const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
  const key = await hmac(`${scope}:${ip}`, env.SESSION_SECRET);
  const row = await env.DB.prepare(`INSERT INTO auth_rate_limits (rate_key,window_start,attempts) VALUES (?,?,1) ON CONFLICT(rate_key) DO UPDATE SET attempts=CASE WHEN auth_rate_limits.window_start<=?-? THEN 1 ELSE auth_rate_limits.attempts+1 END, window_start=CASE WHEN auth_rate_limits.window_start<=?-? THEN excluded.window_start ELSE auth_rate_limits.window_start END RETURNING attempts`).bind(key,now,now,windowSeconds,now,windowSeconds).first();
  return Number(row?.attempts || 1) <= limit;
}

async function sendVerificationEmail(env, email, name, code) {
  if (!env.RESEND_API_KEY || !env.EMAIL_FROM) throw new Error('EMAIL_PROVIDER_NOT_CONFIGURED');
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST', headers: { authorization: `Bearer ${env.RESEND_API_KEY}`, 'content-type': 'application/json' },
    body: JSON.stringify({ from: env.EMAIL_FROM, to: [email], subject: 'Astro Plus email verification', html: `<div style="font-family:Arial,sans-serif"><h2>Astro Plus</h2><p>नमस्ते ${String(name || '').replace(/[<>]/g, '')},</p><p>आपका verification code है:</p><p style="font-size:28px;font-weight:bold;letter-spacing:6px">${code}</p><p>यह कोड 10 मिनट तक मान्य है। यदि आपने यह अनुरोध नहीं किया है तो इस ईमेल को अनदेखा करें।</p></div>` })
  });
  if (!res.ok) throw new Error('EMAIL_SEND_FAILED');
}
async function verifyGoogleCredential(credential, env) {
  const parts = String(credential || '').split('.'); if (parts.length !== 3) throw new Error('INVALID_GOOGLE_TOKEN');
  const header = JSON.parse(new TextDecoder().decode(fromB64url(parts[0])));
  const claims = JSON.parse(new TextDecoder().decode(fromB64url(parts[1])));
  if (header.alg !== 'RS256' || !header.kid) throw new Error('INVALID_GOOGLE_TOKEN');
  if (claims.iss !== 'https://accounts.google.com' && claims.iss !== 'accounts.google.com') throw new Error('INVALID_GOOGLE_ISSUER');
  if (claims.aud !== env.GOOGLE_CLIENT_ID) throw new Error('GOOGLE_AUDIENCE_MISMATCH');
  if (!claims.sub || !claims.email || claims.email_verified !== true || Number(claims.exp) <= Date.now() / 1000) throw new Error('GOOGLE_TOKEN_EXPIRED_OR_UNVERIFIED');
  if (!googleKeysCache || Date.now() > googleKeysExpiry) {
    const response = await fetch('https://www.googleapis.com/oauth2/v3/certs');
    if (!response.ok) throw new Error('GOOGLE_KEYS_UNAVAILABLE');
    const data = await response.json(); googleKeysCache = data.keys || []; googleKeysExpiry = Date.now() + 50 * 60 * 1000;
  }
  const jwk = googleKeysCache.find(k => k.kid === header.kid); if (!jwk) { googleKeysExpiry = 0; throw new Error('GOOGLE_KEY_NOT_FOUND'); }
  const key = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
  const ok = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, fromB64url(parts[2]), encoder.encode(`${parts[0]}.${parts[1]}`));
  if (!ok) throw new Error('GOOGLE_SIGNATURE_INVALID');
  return claims;
}
function normalizeProfile(p) {
  return {
    id: String(p.id || crypto.randomUUID()).slice(0, 80),
    name: String(p.name || '').trim().slice(0, 100),
    date: String(p.date || '').slice(0, 10), time: String(p.time || '').slice(0, 5),
    place: String(p.place || '').trim().slice(0, 180), gender: String(p.gender || '').slice(0, 20),
    lat: p.lat == null || p.lat === '' ? null : (Number.isFinite(Number(p.lat)) ? Number(p.lat) : null),
    lon: p.lon == null || p.lon === '' ? null : (Number.isFinite(Number(p.lon)) ? Number(p.lon) : null)
  };
}

function pathNeedsSecret(path) { return path.startsWith('/api/auth/') || path === '/api/profiles'; }

export async function onRequest(context) {
  const { request, env } = context, url = new URL(request.url), path = url.pathname.replace(/\/+$/, '') || '/';
  if (!path.startsWith('/api/')) return new Response('Not found', { status: 404 });
  if (!checkOrigin(request, env)) return json({ error: 'ORIGIN_NOT_ALLOWED' }, 403);
  if (pathNeedsSecret(path) && (!env.SESSION_SECRET || env.SESSION_SECRET.length < 32)) return json({ error: 'SESSION_SECRET_MISSING', message: 'Cloudflare में SESSION_SECRET (कम-से-कम 32 अक्षर) सेट करें।' }, 503);
  const headers = {};
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: { 'Allow': 'GET,POST,PUT,DELETE,OPTIONS' } });

  if (path === '/api/auth/csrf' && request.method === 'GET') {
    const token = randomToken(24); return json({ csrfToken: token }, 200, { 'set-cookie': cookie('ap_csrf', token, request, { httpOnly: false, maxAge: 86400 }) });
  }
  if (['POST','PUT','DELETE'].includes(request.method) && !checkCsrf(request)) return json({ error: 'CSRF_CHECK_FAILED' }, 403);

  if (path === '/api/auth/email/signup' && request.method === 'POST') {
    if (!await rateLimit(env, request, 'signup', 5, 3600)) return json({ error: 'RATE_LIMITED', message: 'बहुत अधिक प्रयास हुए हैं। एक घंटे बाद फिर कोशिश करें।' }, 429);
    const b = await body(request); const email = cleanEmail(b?.email), name = String(b?.name || '').trim().slice(0, 100), password = String(b?.password || '');
    if (!validEmail(email) || name.length < 1 || password.length < 10 || password.length > 128) return json({ error: 'INVALID_SIGNUP_DETAILS', message: 'नाम, सही ईमेल और कम-से-कम 10 अक्षर का पासवर्ड दें।' }, 400);
    if (await env.DB.prepare('SELECT id FROM users WHERE email=?').bind(email).first()) return json({ error: 'EMAIL_ALREADY_REGISTERED', message: 'यह ईमेल पहले से रजिस्टर्ड है। लॉगिन करें।' }, 409);
    const ph = await passwordHash(password), code = String(crypto.getRandomValues(new Uint32Array(1))[0] % 1000000).padStart(6, '0');
    const codeHash = await hmac(`${email}:${code}`, env.SESSION_SECRET || 'CHANGE_ME_BEFORE_DEPLOY');
    const now = Math.floor(Date.now() / 1000);
    await env.DB.prepare('DELETE FROM pending_signups WHERE email=?').bind(email).run();
    await env.DB.prepare('INSERT INTO pending_signups (email,name,password_salt,password_hash,code_hash,expires_at,created_at) VALUES (?,?,?,?,?,?,?)').bind(email,name,ph.salt,ph.hash,codeHash,now+600,now).run();
    try { await sendVerificationEmail(env, email, name, code); } catch (e) { return json({ error: e.message, message: e.message === 'EMAIL_PROVIDER_NOT_CONFIGURED' ? 'ईमेल भेजने की सेवा अभी सेट नहीं है। Cloudflare में Resend की सेटिंग पूरी करें।' : 'Verification ईमेल नहीं भेजा जा सका।' }, 503); }
    return json({ ok: true, message: 'ईमेल पर 6 अंकों का verification code भेजा गया है।' });
  }
  if (path === '/api/auth/email/verify' && request.method === 'POST') {
    if (!await rateLimit(env, request, 'verify', 10, 3600)) return json({ error: 'RATE_LIMITED', message: 'बहुत अधिक verification प्रयास हुए हैं। बाद में कोशिश करें।' }, 429);
    const b = await body(request), email = cleanEmail(b?.email), code = String(b?.code || '').trim();
    const pending = await env.DB.prepare('SELECT * FROM pending_signups WHERE email=?').bind(email).first();
    const now = Math.floor(Date.now() / 1000);
    if (!pending || pending.expires_at < now || !/^\d{6}$/.test(code)) return json({ error: 'CODE_EXPIRED', message: 'कोड गलत है या उसकी समय-सीमा समाप्त हो गई है।' }, 400);
    const expected = await hmac(`${email}:${code}`, env.SESSION_SECRET || 'CHANGE_ME_BEFORE_DEPLOY');
    if (expected !== pending.code_hash) return json({ error: 'INVALID_CODE', message: 'Verification code सही नहीं है।' }, 400);
    const id = `usr_${crypto.randomUUID()}`;
    await env.DB.prepare('INSERT INTO users (id,email,name,password_salt,password_hash,email_verified,created_at) VALUES (?,?,?,?,?,1,?)').bind(id,email,pending.name,pending.password_salt,pending.password_hash,now).run();
    await env.DB.prepare('DELETE FROM pending_signups WHERE email=?').bind(email).run();
    const sessionCookie = await issueSession(env.DB, id, request);
    const user = await env.DB.prepare('SELECT * FROM users WHERE id=?').bind(id).first();
    return json({ ok: true, user: safeUser(user) }, 200, { 'set-cookie': sessionCookie });
  }
  if (path === '/api/auth/email/login' && request.method === 'POST') {
    if (!await rateLimit(env, request, 'login', 20, 900)) return json({ error: 'RATE_LIMITED', message: 'बहुत अधिक लॉगिन प्रयास हुए हैं। 15 मिनट बाद कोशिश करें।' }, 429);
    const b = await body(request), email = cleanEmail(b?.email), password = String(b?.password || '');
    const user = await env.DB.prepare('SELECT * FROM users WHERE email=?').bind(email).first();
    if (!user || !user.password_hash || !user.password_salt) return json({ error: 'INVALID_CREDENTIALS', message: 'ईमेल या पासवर्ड सही नहीं है।' }, 401);
    const check = await passwordHash(password, user.password_salt);
    if (check.hash !== user.password_hash) return json({ error: 'INVALID_CREDENTIALS', message: 'ईमेल या पासवर्ड सही नहीं है।' }, 401);
    if (!user.email_verified) return json({ error: 'EMAIL_NOT_VERIFIED', message: 'पहले ईमेल verify करें।' }, 403);
    const sessionCookie = await issueSession(env.DB, user.id, request);
    return json({ ok: true, user: safeUser(user) }, 200, { 'set-cookie': sessionCookie });
  }
  if (path === '/api/auth/google' && request.method === 'POST') {
    if (!await rateLimit(env, request, 'google', 20, 900)) return json({ error: 'RATE_LIMITED', message: 'बहुत अधिक लॉगिन प्रयास हुए हैं। 15 मिनट बाद कोशिश करें।' }, 429);
    if (!env.GOOGLE_CLIENT_ID) return json({ error: 'GOOGLE_CLIENT_ID_MISSING', message: 'Google OAuth Client ID सेट नहीं है।' }, 503);
    const b = await body(request); let claims;
    try { claims = await verifyGoogleCredential(b?.credential, env); } catch (e) { return json({ error: e.message, message: 'Google login सत्यापित नहीं हो सका।' }, 401); }
    const email = cleanEmail(claims.email), now = Math.floor(Date.now() / 1000);
    let user = await env.DB.prepare('SELECT * FROM users WHERE google_sub=?').bind(claims.sub).first();
    if (!user) {
      user = await env.DB.prepare('SELECT * FROM users WHERE email=?').bind(email).first();
      if (user) await env.DB.prepare('UPDATE users SET google_sub=?,email_verified=1 WHERE id=?').bind(claims.sub,user.id).run();
      else {
        const id = `usr_${crypto.randomUUID()}`;
        await env.DB.prepare('INSERT INTO users (id,email,name,google_sub,email_verified,created_at) VALUES (?,?,?,?,1,?)').bind(id,email,String(claims.name || '').slice(0,100),claims.sub,now).run();
      }
      user = await env.DB.prepare('SELECT * FROM users WHERE google_sub=?').bind(claims.sub).first();
    }
    const sessionCookie = await issueSession(env.DB, user.id, request);
    return json({ ok: true, user: safeUser(user) }, 200, { 'set-cookie': sessionCookie });
  }
  if (path === '/api/auth/me' && request.method === 'GET') {
    const user = await currentUser(request, env); return user ? json({ authenticated: true, user: safeUser(user) }) : json({ authenticated: false, user: null }, 401);
  }
  if (path === '/api/auth/logout' && request.method === 'POST') {
    const token = cookies(request).ap_session; if (token) await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await sha256(token)).run();
    return json({ ok: true }, 200, { 'set-cookie': cookie('ap_session', '', request, { httpOnly: true, maxAge: 0 }) });
  }
  if (path === '/api/profiles' && request.method === 'GET') {
    const user = await currentUser(request, env); if (!user) return json({ error: 'UNAUTHENTICATED' }, 401);
    const { results } = await env.DB.prepare('SELECT profile_id AS id,name,birth_date AS date,birth_time AS time,place,gender,lat,lon FROM kundli_profiles WHERE user_id=? ORDER BY updated_at DESC').bind(user.id).all();
    return json({ profiles: results || [] });
  }
  if (path === '/api/profiles' && request.method === 'PUT') {
    const user = await currentUser(request, env); if (!user) return json({ error: 'UNAUTHENTICATED' }, 401);
    const b = await body(request), list = Array.isArray(b?.profiles) ? b.profiles : null;
    if (!list || list.length > 100) return json({ error: 'INVALID_PROFILE_LIST' }, 400);
    const now = Math.floor(Date.now() / 1000), statements = [env.DB.prepare('DELETE FROM kundli_profiles WHERE user_id=?').bind(user.id)];
    for (const raw of list) {
      const p = normalizeProfile(raw);
      if (!p.name || !/^\d{4}-\d{2}-\d{2}$/.test(p.date) || !/^\d{2}:\d{2}$/.test(p.time) || !p.place) continue;
      statements.push(env.DB.prepare('INSERT INTO kundli_profiles (profile_id,user_id,name,birth_date,birth_time,place,gender,lat,lon,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)').bind(p.id,user.id,p.name,p.date,p.time,p.place,p.gender,p.lat,p.lon,now));
    }
    await env.DB.batch(statements.slice(0, 50));
    for (let i = 50; i < statements.length; i += 50) await env.DB.batch(statements.slice(i, i + 50));
    return json({ ok: true, count: statements.length - 1 });
  }
  return json({ error: 'NOT_FOUND' }, 404);
}
